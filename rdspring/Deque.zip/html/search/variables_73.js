var searchData=
[
  ['s',['s',['../classDequeTest.html#ad5c2913e9aecffb354adddc16f67c390',1,'DequeTest::s()'],['../classIteratorTest.html#a4742de154a98308e5ecb942a8d7c3cf5',1,'IteratorTest::s()']]],
  ['sizet',['SIZET',['../Deque_8h.html#a0534a8811039e5f05ee60619292ab8fa',1,'Deque.h']]],
  ['st',['st',['../classDequeTest.html#a012448dc46d4e672a197b1c7165c7007',1,'DequeTest']]]
];

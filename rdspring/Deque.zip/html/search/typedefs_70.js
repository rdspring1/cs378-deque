var searchData=
[
  ['pointer',['pointer',['../structMy__Allocator.html#a538f5c213423dfe771b646dcf63cf42a',1,'My_Allocator::pointer()'],['../classMyDeque.html#a9af39f8c74b12cfa2a1577a0cac4346a',1,'MyDeque::pointer()'],['../classMyDeque_1_1const__iterator.html#a659cf7a7bad02f8dfb4a4f35109c5ebe',1,'MyDeque::const_iterator::pointer()'],['../classMyDeque_1_1iterator.html#a53ab0269d52f5abc239c3464f84f41f5',1,'MyDeque::iterator::pointer()']]]
];

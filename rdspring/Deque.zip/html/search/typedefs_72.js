var searchData=
[
  ['reference',['reference',['../structMy__Allocator.html#af4645f2fa18ec0d5ce51984403b33a73',1,'My_Allocator::reference()'],['../classMyDeque.html#a9e89ddd823825b5b1e97489f54193e5a',1,'MyDeque::reference()'],['../classMyDeque_1_1iterator.html#ad298e03aa9f5460ea334b8925a3f0fec',1,'MyDeque::iterator::reference()'],['../classMyDeque_1_1const__iterator.html#a13a833578cec3971fb524e06370911b9',1,'MyDeque::const_iterator::reference()']]]
];

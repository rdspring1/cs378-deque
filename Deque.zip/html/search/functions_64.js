var searchData=
[
  ['deallocate',['deallocate',['../structMy__Allocator.html#a29aec0a80ff412165a85b98e5e81033a',1,'My_Allocator']]],
  ['destroy',['destroy',['../structMy__Allocator.html#a0a81113b7873e61b4841caf38ac55bfd',1,'My_Allocator::destroy()'],['../Deque_8h.html#ae5ccf961a6e64163beab1ef8f8934fe5',1,'destroy():&#160;Deque.h']]]
];
